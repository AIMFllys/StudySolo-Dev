# Core configuration package
